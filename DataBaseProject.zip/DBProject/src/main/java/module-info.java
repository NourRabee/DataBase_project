module com.example.dbproject {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires validatorfx;
    requires java.sql;
    requires de.jensd.fx.glyphs.fontawesome;

    opens databasefinalproject to javafx.fxml;
    exports databasefinalproject;
    exports models;
    opens models to javafx.fxml;
}