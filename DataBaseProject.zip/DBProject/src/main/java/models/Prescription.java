package models;

import java.sql.Time;
import java.util.Date;

public class Prescription {

    private Patient patient;
    private Medicine Med_code;
    private String Dosage;
    private Date Presentdate;
    private Time PresentTime;
    private boolean deleted;

    public Prescription(Patient patient, Medicine med_code, String dosage, Date presentdate, Time presentTime, boolean deleted) {
        this.patient = patient;
        Med_code = med_code;
        Dosage = dosage;
        Presentdate = presentdate;
        PresentTime = presentTime;
        this.deleted = deleted;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public Medicine getMed_code() {
        return Med_code;
    }

    public void setMed_code(Medicine med_code) {
        Med_code = med_code;
    }

    public String getDosage() {
        return Dosage;
    }

    public void setDosage(String dosage) {
        Dosage = dosage;
    }

    public Date getPresentdate() {
        return Presentdate;
    }

    public void setPresentdate(Date presentdate) {
        Presentdate = presentdate;
    }

    public Time getPresentTime() {
        return PresentTime;
    }

    public void setPresentTime(Time presentTime) {
        PresentTime = presentTime;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }
}
