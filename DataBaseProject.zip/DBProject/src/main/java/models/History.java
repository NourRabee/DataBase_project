package models;

public class History {
    private Patient patient;
    private String BloodType;
    private String allergy;

    public History(Patient patient, String BloodType, String allergy) {
        this.patient = patient;
        this.BloodType = BloodType;
        this.allergy = allergy;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public String getBloodType() {
        return BloodType;
    }

    public void setBloodType(String BloodType) {
        this.BloodType = BloodType;
    }

    public String getAllergy() {
        return allergy;
    }

    public void setAllergy(String allergy) {
        this.allergy = allergy;
    }
}
