package models;

import java.sql.Time;
import java.util.Date;

public class Diagnosis {

    private Patient patient;
    private Doctor doctor;
    private Time Diagnosis_Time;
    private Date Diagnosis_date;
    private String diagnose;
    private String treatment;
    private String Complaints;

    public Diagnosis(Patient patient, Doctor doctor, Time diagnosis_Time, Date diagnosis_date, String diagnose, String treatment, String complaints) {
        this.patient = patient;
        this.doctor = doctor;
        Diagnosis_Time = diagnosis_Time;
        Diagnosis_date = diagnosis_date;
        this.diagnose = diagnose;
        this.treatment = treatment;
        Complaints = complaints;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public int getPatientId() {
        return patient.getId();
    }

    public String getPatientName() {
        return patient.getPname();
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public int getDoctortId() {
        return doctor.getId();
    }

    public String getDoctorName() {
        return doctor.getName();
    }

    public String getDoctorSpecialization() {
        return doctor.getSpecialization();
    }

    public Time getDiagnosis_Time() {
        return Diagnosis_Time;
    }

    public void setDiagnosis_Time(Time diagnosis_Time) {
        Diagnosis_Time = diagnosis_Time;
    }

    public Date getDiagnosis_date() {
        return Diagnosis_date;
    }

    public void setDiagnosis_date(Date diagnosis_date) {
        Diagnosis_date = diagnosis_date;
    }

    public String getDiagnose() {
        return diagnose;
    }

    public void setDiagnose(String diagnose) {
        this.diagnose = diagnose;
    }

    public String getTreatment() {
        return treatment;
    }

    public void setTreatment(String treatment) {
        this.treatment = treatment;
    }

    public String getComplaints() {
        return Complaints;
    }

    public void setComplaints(String complaints) {
        Complaints = complaints;
    }
}
