package models;

import java.sql.Time;
import java.util.Date;

public class Appointment {
    private Patient patient;
    private Doctor doctor;
    private Date appointmentDate;
    private Time startTime;
    private Time endTime;

    public Appointment(Patient patient, Doctor doctor, Date appointmentDate, Time startTime, Time endTime) {
        this.patient = patient;
        this.doctor = doctor;
        this.appointmentDate = appointmentDate;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public  Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public int getPatientId() {
        return patient.getId();
    }

    public String getPatientName() {
        return patient.getPname();
    }

    public int getDoctortId() {
        return doctor.getId();
    }

    public String getDoctorName() {
        return doctor.getName();
    }

    public String getDoctorSpecialization() {
        return doctor.getSpecialization();
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(Date appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public Time getStartTime() {
        return startTime;
    }

    public void setStartTime(Time startTime) {
        this.startTime = startTime;
    }

    public Time getEndTime() {
        return endTime;
    }

    public void setEndTime(Time endTime) {
        this.endTime = endTime;
    }
}
