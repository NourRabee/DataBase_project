package databasefinalproject;

import models.Doctor;

public final class UserSessionD {  // can't make inheritance

    private static UserSessionD instance;  // variable

    private Doctor doctor; // object from Doctor class

    private UserSessionD(Doctor doctor) { // to make access
        this.doctor = doctor;
    }

    public static UserSessionD getInstance(Doctor doctor) {
        if (instance == null || instance.getDoctor()==null) {
            instance = new UserSessionD(doctor);
        }
        return instance;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void cleanUserSession() {
        doctor = null;
    }

}