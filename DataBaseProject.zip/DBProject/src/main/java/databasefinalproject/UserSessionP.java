package databasefinalproject;

import models.Patient;

public class UserSessionP {

    private static UserSessionP instance;

    private Patient patient;

    private UserSessionP(Patient patient) {
        this.patient = patient;
    }

    public static UserSessionP getInstance(Patient patient) {
        if (instance == null || instance.getPatient()==null) {

            instance = new UserSessionP(patient);
        }
        return instance;
    }

    public Patient getPatient() {
        return patient;
    }

    public void cleanUserSession() {
        patient = null;
    }
}

