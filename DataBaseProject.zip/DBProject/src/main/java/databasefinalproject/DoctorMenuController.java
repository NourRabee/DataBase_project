package databasefinalproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

public class DoctorMenuController {

    public void profile_buttonClicked(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Doctor1profile.fxml"));
        Node node = (Node) actionEvent.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        stage.setMaximized(true);
        Scene scene = new Scene(fxmlLoader.load(), 1550, 795);
        stage.setTitle("Clinic Patients");
        stage.setScene(scene);
        stage.show();
    }

    public void clinicP_buttonClicked(ActionEvent actionEvent) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Doctor2Clinicp.fxml"));
        Node node = (Node) actionEvent.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        stage.setMaximized(true);
        Scene scene = new Scene(fxmlLoader.load(), 1550, 795);
        stage.setTitle("Clinic Patients");
        stage.setScene(scene);
        stage.show();
    }

    public void patientsHistory_buttonClicked(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Doctor4phistory.fxml"));
        Node node = (Node) actionEvent.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        stage.setMaximized(true);
        Scene scene = new Scene(fxmlLoader.load(), 1550, 795);
        stage.setTitle("Clinic Patients");
        stage.setScene(scene);
        stage.show();
    }

    public void editPW_buttonClicked(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Doctor8password .fxml"));
        Node node = (Node) actionEvent.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        stage.setMaximized(true);
        Scene scene = new Scene(fxmlLoader.load(), 1550, 795);
        stage.setTitle("Clinic Patients");
        stage.setScene(scene);
        stage.show();
    }


    public void reservation_buttonClicked(ActionEvent actionEvent) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Doctor3appointment.fxml"));
        Node node = (Node) actionEvent.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load(), 1550, 795);
        stage.setMaximized(true);
        stage.setTitle("Doctor");
        stage.setScene(scene);
        stage.show();
    }

    public void patientsPerspiction_buttonClicked(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Doctor5perspiction.fxml"));
        Node node = (Node) actionEvent.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load(), 1550, 795);
        stage.setMaximized(true);
        stage.setTitle("Doctor");
        stage.setScene(scene);
        stage.show();
    }

    public void patientsLabRequest_buttonClicked(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Doctor6LapRequest.fxml"));
        Node node = (Node) actionEvent.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load(), 1550, 795);
        stage.setMaximized(true);
        stage.setTitle("Doctor");
        stage.setScene(scene);
        stage.show();
    }

    public void patientsTransfer_buttonClicked(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Doctor7transfer.fxml"));
        Node node = (Node) actionEvent.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load(), 1550, 795);
        stage.setMaximized(true);
        stage.setTitle("Doctor");
        stage.setScene(scene);
        stage.show();
    }
}
