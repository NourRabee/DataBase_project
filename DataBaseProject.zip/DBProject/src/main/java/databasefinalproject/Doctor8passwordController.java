package databasefinalproject;

import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import models.Doctor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Doctor8passwordController {
    public TextField tf_newpass;
    public TextField tf_oldpass;
    public TextField tf_new2;
    public Label message;

    public void changePassword(ActionEvent actionEvent) {
        Doctor doctor= UserSessionD.getInstance(null).getDoctor();
        if (tf_newpass.getText().equals(tf_new2.getText())){    // check if equal new pwd and confirmation
            try {
                Connection conn = Database.ConnectDb();
                String sql = "SELECT * from doctor where D_ID=? and Dpassword=? "; // get the doctor with logged in id and old pwd value
                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setInt(1,doctor.getId());
                pst.setInt(2,Integer.parseInt(tf_oldpass.getText()));

                ResultSet rs=pst.executeQuery();
                if (rs.next()){ // old pass is correct
                    sql="UPDATE doctor set Dpassword=? where D_ID=?";
                    pst=conn.prepareStatement(sql);
                    pst.setInt(1,Integer.parseInt(tf_newpass.getText()));
                    pst.setInt(2,doctor.getId());
                    pst.execute();
                    if (pst.getUpdateCount()>0){
                        message.setStyle("-fx-text-fill: GREEN");
                        message.setText("Password updated");
                    }
                    else {
                        message.setStyle("-fx-text-fill: RED");
                        message.setText("Error in Update");
                    }
                }
                else{
                    message.setStyle("-fx-text-fill: RED");
                    message.setText("Old password is wrong");
                }

            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }

        }
        else{
            message.setStyle("-fx-background-color: RED");
            message.setText("Passwords must match");
        }

    }
}
