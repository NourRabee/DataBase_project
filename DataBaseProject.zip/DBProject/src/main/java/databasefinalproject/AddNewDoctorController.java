package databasefinalproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AddNewDoctorController {


    @FXML
    private Label L_passWord;

    @FXML
    private Button Save;

    @FXML
    private Button clean;

    @FXML
    private TextField tf_Email;

    @FXML
    private TextField tf_address;

    @FXML
    private TextField tf_id;

    @FXML
    private TextField tf_name;

    @FXML
    private TextField tf_phoneNum;

    @FXML
    private TextField tf_specialization;

    ResultSet rs;


    @FXML
    public void Save_buttonClicked(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {

        String id = tf_id.getText();
        String name = tf_name.getText();
        String email = tf_Email.getText();
        String address = tf_address.getText();
        String phone_number = tf_phoneNum.getText();
        String specialization = tf_specialization.getText();

        rs = Database.select("SELECT D_ID FROM doctor where D_ID = '"+tf_id.getText()+"'");

        if (name.isEmpty() || id.isEmpty() || address.isEmpty() || email.isEmpty() || phone_number.isEmpty() || specialization.isEmpty()) {

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Please Fill All DATA");
            alert.showAndWait();

        }else if(rs.next()){

            Alert alert2 = new Alert(Alert.AlertType.ERROR);
            alert2.setHeaderText(null);
            alert2.setContentText("This doctor already exists!");
            alert2.showAndWait();
            clean_ButtonClicked();

        } else {

            String query = "INSERT INTO Doctor(D_ID, D_password, D_name, specialization, address, email, phone) VALUES ('" + tf_id.getText() + "','" +
                    tf_id.getText() + "','" + tf_name.getText() + "','" + tf_specialization.getText() + "','" + tf_address.getText() +"','" + tf_Email.getText() + "','"+ tf_phoneNum.getText() +"')";
            System.out.println(query);
            Database.execute(query);
            String lable = "     Your password is " + tf_id.getText();
            L_passWord.setText(lable);
            L_passWord.setStyle("-fx-text-fill: Red");
            clean_ButtonClicked();
        }

    }

    @FXML
    private void clean_ButtonClicked() {
        tf_address.setText(null);
        tf_specialization.setText(null);
        tf_name.setText(null);
        tf_phoneNum.setText(null);
        tf_Email.setText(null);
        tf_id.setText(null);
    }


}
