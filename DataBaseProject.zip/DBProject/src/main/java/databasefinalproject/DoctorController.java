package databasefinalproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import models.Doctor;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class DoctorController {

    @FXML
    private Label check;

    @FXML
    private Label ID_label;

    @FXML
    private Label pw_Label;

    @FXML
    private Button submitButton;

    @FXML
    private TextField tf_ID;

    @FXML
    private PasswordField tf_PW;


    @FXML
    public void submit(ActionEvent actionEvent) {
        try{
            Connection connect = Database.ConnectDb();
                    

            String username = tf_ID.getText();
            String password = tf_PW.getText();


            String sql1 = "SELECT * FROM doctor WHERE D_ID =" + Integer.parseInt(username)+" and Dpassword="+ Integer.parseInt(password);
            Statement stmt = connect.createStatement();
            ResultSet rs1 = stmt.executeQuery(sql1);


            if(!rs1.next()){ // comparing rs(sql query with user input

                check.setText("Login Failed!");
            }
            else{
            		Doctor doctor=new Doctor(rs1.getInt("D_ID"),0,rs1.getString("D_name"),rs1.getString("specialization"),rs1.getString("address"),
            				rs1.getString("email"),rs1.getInt("phone"));
               
                	

                    check.setText("Login has done successfully!");
                    Stage stage = new Stage();
                    FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Doctor1Profile.fxml"));
                    Scene scene = new Scene(fxmlLoader.load());
                    Doctor1ProfileController dc=fxmlLoader.<Doctor1ProfileController>getController();
                    dc.setProfile(doctor);
                    stage.setScene(scene);
                    stage.show();
                    
                    /*Patient1Controller patient = new Patient1Controller();
                    patient.displayInfo(Integer.parseInt(username));*/

                }


        }
        catch (Exception e) {
            System.out.println(e);
            //JOptionPane.showMessageDialog(null, e);
        }

    }


}

