package databasefinalproject;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class p3_Delete_Appointment_Controller implements Initializable {

    @FXML
    private Button Delete;

    @FXML
    private ChoiceBox<?> TimeChoiceBox;

    @FXML
    private Button clear;

    @FXML
    private DatePicker tf_date;


    ResultSet rs;

    // get doctor id from UserSessionD class
    int patientID = UserSessionP.getInstance(null).getPatient().getId();

    // To control the Scene builder tools
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        // event listener ,, as sensors
        // observable, oldDate, newDate : the Observablelist we will fill it , The old date,  and the new date
        tf_date.valueProperty().addListener((observable, oldDate, newDate) -> {

                ObservableList reservedTimes = getReservedTimes(newDate, patientID);
                TimeChoiceBox.setItems(reservedTimes);

//                if (reservedTimes.isEmpty()){
//                    Alert alert2 = new Alert(Alert.AlertType.ERROR);
//                    alert2.setHeaderText(null);
//                    alert2.setContentText("You dont have any appointment on this date "+ tf_date.getValue());
//                    alert2.showAndWait();
//                    clear_ButtonClicked();
//                }

        });
    }

    public void Delete_buttonClicked(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {


        // if we delete all the appointment in selected date
         if ( tf_date.getValue() != null && TimeChoiceBox.getValue() == null) {

            String sql = "DELETE FROM appointment WHERE A_date = '" + java.sql.Date.valueOf(tf_date.getValue()) + "' and P_ID ='" + patientID + "'";
            try {
                Database.execute(sql);
                clear_ButtonClicked();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        //else if we delete all the appointments for a specific patient
        else if ( tf_date.getValue() != null && TimeChoiceBox.getValue() != null) {
            String time = String.valueOf(TimeChoiceBox.getValue());
            String sql = "DELETE FROM appointment WHERE P_ID ='" + patientID + "' and A_date = '"+java.sql.Date.valueOf(tf_date.getValue())+"' and StartTime = '"+java.sql.Time.valueOf(time)+"'";
            try {
                    Database.execute(sql);
                    clear_ButtonClicked();
//
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    // if we want to delete an appointment according Date
    public static ObservableList<String> getReservedTimes(LocalDate appointmentDate, int patientID) {
        ObservableList<String> reservedTimes = FXCollections.observableArrayList();
        try {

            // define and execute the query
            // ResultSet object is a table of data representing a database result set
            String sql = "SELECT * from appointment where P_ID= '" + patientID + "' and A_date = '" + appointmentDate.toString() + "'";
            ResultSet rs = Database.select(sql);

            // (rs. next()) means that if the next row is not null (means if it exists)
            while (rs.next()) {
                reservedTimes.add(rs.getString("StartTime"));
            }

        } catch (SQLException e) {
            System.out.println(e);
        } finally {
//                            if (reservedTimes.isEmpty()){
//                    Alert alert2 = new Alert(Alert.AlertType.ERROR);
//                    alert2.setHeaderText(null);
//                    alert2.setContentText("You dont have any appointment on this date "+ appointmentDate);
//                    alert2.showAndWait();
//                }
            return reservedTimes;
        }
    }

    public void clear_ButtonClicked() {
        TimeChoiceBox.setValue(null);
        tf_date.setValue(null);
    }


}



