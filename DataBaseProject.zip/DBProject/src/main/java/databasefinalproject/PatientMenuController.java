package databasefinalproject;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.io.IOException;

public class PatientMenuController {

        @FXML
        private Button clinicD;

        @FXML
        private Button contactInfo;

        @FXML
        private Button editPW;

        @FXML
        private Button patientsHistory;

        @FXML
        private Button profile;

        @FXML
        private Button reservation;

        @FXML
        void clinicD_buttonClicked(ActionEvent actionEvent) throws IOException {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Patient2clinicD.fxml"));
            Node node = (Node) actionEvent.getSource();
            Stage stage = (Stage) node.getScene().getWindow();
            stage.setMaximized(true);
            Scene scene = new Scene(fxmlLoader.load(), 1550, 795);
            stage.setTitle("Clinic Doctors");
            stage.setScene(scene);
            stage.show();
        }

        @FXML
        void contactInfo_buttonClicked(ActionEvent actionEvent) throws IOException {
                FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Patient6informations.fxml"));
                Node node = (Node) actionEvent.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                stage.setMaximized(true);
                Scene scene = new Scene(fxmlLoader.load(), 1550, 795);
                stage.setTitle("Contact information's");
                stage.setScene(scene);
                stage.show();
        }


        @FXML
        void editPW_buttonClicked(ActionEvent actionEvent) throws IOException {
                FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Patient5password.fxml"));
                Node node = (Node) actionEvent.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                stage.setMaximized(true);
                Scene scene = new Scene(fxmlLoader.load(), 1550, 795);
                stage.setTitle("Reset Password");
                stage.setScene(scene);
                stage.show();

        }

        @FXML
        void patientsHistory_buttonClicked(ActionEvent actionEvent) throws IOException {
                FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Patient4history.fxml"));
                Node node = (Node) actionEvent.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                stage.setMaximized(true);
                Scene scene = new Scene(fxmlLoader.load(), 1550, 795);
                stage.setTitle("Patients History");
                stage.setScene(scene);
                stage.show();

        }

        @FXML
        void profile_buttonClicked(ActionEvent actionEvent) throws IOException {
                FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Patient1Profile.fxml"));
                Node node = (Node) actionEvent.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                stage.setMaximized(true);
                Scene scene = new Scene(fxmlLoader.load(), 1550, 795);
                stage.setTitle("Patient Profile");
                stage.setScene(scene);
                stage.show();


        }

        @FXML
            void reservation_buttonClicked(ActionEvent actionEvent) throws IOException {
                FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Patient3appointment.fxml"));
                Node node = (Node) actionEvent.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                stage.setMaximized(true);
                Scene scene = new Scene(fxmlLoader.load(), 1550, 795);
                stage.setTitle("Appointment Reservation");
                stage.setScene(scene);
                stage.show();


            }

    }


