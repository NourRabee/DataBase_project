package databasefinalproject;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Doctor;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;

public class Patient2Controller implements Initializable {

    @FXML
    private TableView<Doctor> clinicDTable;

    @FXML
    private TableColumn<Doctor, Integer> doctorIDCol;

    @FXML
    private TableColumn<Doctor, String> doctorNameCol;

    @FXML
    private TableColumn<Doctor, String> specializationCol;

    @FXML
    private TextField tf_search;

    ObservableList<Doctor> list = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try{

            ResultSet rs = Database.select("SELECT D_ID, D_name, specialization FROM doctor");

            while (rs.next()){

                list.add(new Doctor(rs.getInt("D_ID"),
                        rs.getString("D_name"),
                        rs.getString("specialization")));

            }
            doctorIDCol.setCellValueFactory(new PropertyValueFactory<Doctor, Integer>("id"));
            doctorNameCol.setCellValueFactory(new PropertyValueFactory<Doctor, String >("name"));
            specializationCol.setCellValueFactory(new PropertyValueFactory<Doctor, String>("specialization"));

            clinicDTable.setItems(list);

            //wrap the observationalList "list" in a FilteredList (initially display all data)
            FilteredList<Doctor> filterList = new FilteredList<>(list, b -> true);

            //set the filter predict whenever the text field changes.
            tf_search.textProperty().addListener((observable, newValue, oldValue) -> {
                filterList.setPredicate(doctor -> {

                    //if the tf_search is empty, display all the patients

                    if (newValue.isEmpty() || newValue.isBlank() || newValue == null) {

                        return true;

                    }
                    String searchKeyword = newValue.toLowerCase();

                    if (String.valueOf(doctor.getId()).indexOf(searchKeyword) > -1) {

                        return true; //means we find match in doctor ID

                    } else if (doctor.getName().toLowerCase().indexOf(searchKeyword) > -1) {

                        return true;

                    } else if (doctor.getSpecialization().toLowerCase().indexOf(searchKeyword) > -1) {

                        return true;
                    } else
                        return false;// no match found

                });

            });
            SortedList<Doctor> sortedData = new SortedList<>(filterList);

            //Bind sorted result with table view "patientTable"
            sortedData.comparatorProperty().bind(clinicDTable.comparatorProperty());

            //Apply filtered and sorted data to the table View.setItems(sortedData);

            clinicDTable.setItems(sortedData);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}

