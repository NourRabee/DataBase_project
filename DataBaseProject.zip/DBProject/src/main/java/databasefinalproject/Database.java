package databasefinalproject;

import java.sql.*;

public class Database {


    public static Connection ConnectDb() {
        try {
            //Class.forName("com.mysql.jdbc.Driver"+"?verifyServerCertificate=false");
            //JOptionPane.showMessageDialog(null, "Connection Established");
            return (Connection) DriverManager.getConnection("jdbc:mysql://localhost/clinic", "root", "hadeel323139378");
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }


    public static ResultSet select(String SQL) throws SQLException, ClassNotFoundException {
        System.out.println(SQL);
        Connection con = Database.ConnectDb();
        Statement stmt = con.createStatement();
        return stmt.executeQuery(SQL);
    }
    public static void execute(String SQL) throws ClassNotFoundException, SQLException {
        System.out.println(SQL);
        Connection con = Database.ConnectDb();
        Statement stmt = con.createStatement();
        stmt.executeUpdate(SQL);
        stmt.close();
        con.close();
    }
}
