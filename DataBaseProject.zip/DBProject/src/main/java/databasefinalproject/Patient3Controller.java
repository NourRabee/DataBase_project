package databasefinalproject;


import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import models.Appointment;
import models.Doctor;
import models.Patient;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.Date;
import java.util.ResourceBundle;

public class Patient3Controller implements Initializable {

    @FXML
    private TableColumn<Appointment, Date> Datecol;

    @FXML
    private TableColumn<Appointment, Time> TimeCol;

    @FXML
    private FontAwesomeIconView add_new_appointment;

    @FXML
    private TableView<Appointment> appointmentTable;

    @FXML
    private FontAwesomeIconView delete;

    @FXML
    private TableColumn<Appointment, Integer> idcol;

    @FXML
    private TableColumn<Appointment, String> namecol;

    @FXML
    private FontAwesomeIconView refresh;

    @FXML
    private TableColumn<Appointment, String> specialityCol;

    ObservableList<Appointment> TableList = FXCollections.observableArrayList();
    int patientID = UserSessionP.getInstance(null).getPatient().getId();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        idcol.setCellValueFactory(new PropertyValueFactory<Appointment, Integer>("DoctortId"));
        namecol.setCellValueFactory(new PropertyValueFactory<Appointment, String >("DoctorName"));
        specialityCol.setCellValueFactory(new PropertyValueFactory<Appointment, String >("DoctorSpecialization"));
        Datecol.setCellValueFactory(new PropertyValueFactory<Appointment, Date>("appointmentDate"));
        TimeCol.setCellValueFactory(new PropertyValueFactory<Appointment, Time>("startTime"));

        try {

            // define and execute the query
            // ResultSet object is a table of data representing a database result set

            ResultSet rs = Database.select("SELECT * FROM appointment a, patient p, patients_history ph, doctor d where  a.P_ID=p.P_ID" +
                    " and a.P_ID=ph.P_ID and a.D_ID = d.D_ID and a.P_ID='"+patientID+"'");

            // (rs. next()) means that if the next row is not null (means if it exists)
            while (rs.next()) {
                // sending DataBase columns as constructors to tables classes

                TableList.add(new Appointment(new Patient(rs.getInt("P_ID"),
                        rs.getString("P_name"),
                        rs.getString("address"),
                        rs.getString("email"),
                        rs.getDate("birth").toLocalDate(),
                        rs.getInt("phone"),
                        rs.getString("blood_type"),
                        rs.getString("allergy")),
                        new Doctor(rs.getInt("D_ID"),
                                0,
                                rs.getString("D_name"),
                                rs.getString("specialization"),
                                rs.getString("address"),
                                rs.getString("email"),
                                rs.getInt("phone")),
                        rs.getDate("A_date"),
                        rs.getTime("StartTime"),
                        rs.getTime("EndTime")));

            }
            // To fill the table view
            appointmentTable.setItems(TableList);

        } catch (Exception ex) {
            System.out.println(ex);
        }
    }


    @FXML
    void add_new_appointment(MouseEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("p3_Add_New_Appointment.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Add Appointment");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void delete(MouseEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("p3_delete_appointment.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Delete Appointment");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void refresh(MouseEvent event) throws SQLException, ClassNotFoundException {

        TableList.clear();

        ResultSet rs = Database.select("SELECT * FROM appointment a, patient p, patients_history ph, doctor d where  a.P_ID=p.P_ID" +
                " and a.P_ID=ph.P_ID and a.D_ID = d.D_ID and a.P_ID='" + patientID + "'");

        // (rs. next()) means that if the next row is not null (means if it exists)
        while (rs.next()) {
            // sending DataBase columns as constructors to tables classes

            TableList.add(new Appointment(new Patient(rs.getInt("P_ID"),
                    rs.getString("P_name"),
                    rs.getString("address"),
                    rs.getString("email"),
                    rs.getDate("birth").toLocalDate(),
                    rs.getInt("phone"),
                    rs.getString("blood_type"),
                    rs.getString("allergy")),
                    new Doctor(rs.getInt("D_ID"),
                            0,
                            rs.getString("D_name"),
                            rs.getString("specialization"),
                            rs.getString("address"),
                            rs.getString("email"),
                            rs.getInt("phone")),
                    rs.getDate("A_date"),
                    rs.getTime("StartTime"),
                    rs.getTime("EndTime")));

        }
        // To fill the table view
        appointmentTable.setItems(TableList);

    }


}



