package databasefinalproject;

import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import models.Doctor;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DoctorViewController {
    @FXML
    private Label check;

    @FXML
    private Label ID_label;

    @FXML
    private Label pw_Label;

    @FXML
    private Button submitButton;

    @FXML
    private TextField tf_ID;

    @FXML
    private PasswordField tf_PW;


    String username;
    String d_password;
    ResultSet rs1;
    private static Stage stg;


    @FXML
    public void submit(ActionEvent actionEvent) {

        String username = tf_ID.getText();
        String d_password = tf_PW.getText();

        try {
            rs1 = Database.select("SELECT * FROM doctor WHERE D_ID =" + Integer.parseInt(username)+" and D_password="+ Integer.parseInt(d_password));


            if (!rs1.next()) { // comparing sql query with the user input

                check.setText("Login Failed!");
            } else {

                Doctor doctor=new Doctor(rs1.getInt("D_ID"),0,rs1.getString("D_name"),rs1.getString("specialization"),rs1.getString("address"),
                        rs1.getString("email"),rs1.getInt("phone"));

                check.setText("Login has done successfully!");

                FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Doctor1profile.fxml"));
                Stage stage = new Stage();
                Scene scene = new Scene(fxmlLoader.load(), 1550, 795);
                Doctor1ProfileController dc =fxmlLoader.<Doctor1ProfileController>getController();
                dc.setProfile(doctor);
                stage.setScene(scene);

                Main m = new Main();
                m.changeScene("Doctor1profile.fxml");

            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }

    }

    public void BackButtonClick() throws IOException {
        Main m = new Main();
        m.changeScene("MainView.fxml");
    }

}
